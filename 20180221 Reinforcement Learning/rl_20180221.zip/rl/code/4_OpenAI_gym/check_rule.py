import gym

env = gym.make('MountainCar-v0')
#env = gym.make('CartPole-v0')
observation = env.reset()


action = env.action_space.sample()
print(action)


observation, reward, done, info = env.step(action)
print(observation)