import time
import numpy as np

from sklearn import preprocessing
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import VotingClassifier

def get_svm_model():
    clf = SVC(gamma='auto')
    return clf

def get_rfc_model():
    forest = RandomForestClassifier(n_estimators=100, random_state=1)
    return forest

def train_with_voting(m1, m2, X, y):
    eclf = VotingClassifier(estimators=[('svm', m1), ('rfc', m2)], voting='hard')

    # 交叉驗證
    for clf, label in zip([m1, m2, eclf], ['SVM', 'Random Forest', 'Ensemble']):
        scores = cross_val_score(clf, X, y, cv=5, scoring='accuracy')
        print("Accuracy: %0.2f (+/- %0.2f) [%s]" % (scores.mean(), scores.std(), label))

if __name__ == '__main__':
    
    X_path = '../03/data/training_data.npy'
    X = np.load(X_path)
    X_normalized = preprocessing.normalize(X, norm='l2')
    print(X.shape)

    Y_path = '../03/data/label_data.npy'
    Y = np.load(Y_path)
    print(Y.T[0].shape)
    

    svm = get_svm_model()
    rfc = get_rfc_model()

    tStart = time.time()#計時開始

    train_with_voting(svm, rfc, X, Y.T[0])
    
    tEnd = time.time()#計時結束
    print(time.strftime('%H:%M:%S', time.gmtime(tEnd - tStart)))
