from gensim.models import word2vec

MODEL_PATH = "./model/word2vec_sg.model"

model = word2vec.Word2Vec.load(MODEL_PATH)

#print(type(model.wv['shopkrio']))

#print(model.wv['shopkrio'].shape)

#s = model.wv.similarity('cugfkt-cduf', 'shopkrio')

#print(s)