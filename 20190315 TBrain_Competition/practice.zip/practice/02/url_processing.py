import os
import json
import pandas as pd

def processing(INPUT_FILE):

    df = pd.read_csv(INPUT_FILE, sep='\t')

    #TODO

if __name__ == '__main__':
    
    INPUT_FILE = "./data/TBN_CUST_BEHAVIOR_0.csv"

    processing(INPUT_FILE)