import os
import logging

from gensim.models import word2vec

def train_word2vec(DOC_PATH, SAVE_PATH):

    logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

    sentences = word2vec.LineSentence(DOC_PATH)

    model = word2vec.Word2Vec(sentences, hs=1, min_count=1, window=3, size=100, sg=1)

    model.save(SAVE_PATH)

    # load model
    # model = word2vec.Word2Vec.load(MODEL_PATH)

if __name__ == '__main__':

    DOC_PATH = './url_word.txt'

    MODEL_NAME = "word2vec.model"

    train_word2vec(DOC_PATH, MODEL_NAME)




