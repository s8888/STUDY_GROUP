import time
import numpy as np

from sklearn import preprocessing
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV


def print_best_score(gsearch,param_test):
    # 輸出 best score
    print("Best score: %0.3f" % gsearch.best_score_)
    print("Best parameters set:")
    # 輸出最佳的分類器到底使用了哪個参数
    best_parameters = gsearch.best_estimator_.get_params()
    for param_name in sorted(param_test.keys()):
        print("\t%s: %r" % (param_name, best_parameters[param_name]))

def grid_search(X, Y, model, param):

    gsearch = GridSearchCV(model, param, cv=5)

    gsearch.fit(X, Y)

    print_best_score(gsearch, param)

def get_model():
    forest = RandomForestClassifier(random_state=1, n_estimators=100,)
    return forest

if __name__ == '__main__':
    X_path = '../03/data/training_data.npy'
    X = np.load(X_path)
    X_normalized = preprocessing.normalize(X, norm='l2')
    print(X.shape)

    Y_path = '../03/data/label_data.npy'
    Y = np.load(Y_path)
    print(Y.T[0].shape)
    
    model = get_model()

    param = {'max_features':range(3, 16, 2)}

    # param = {'n_estimators':range(50, 151, 25)}

    # param = {'max_depth':range(3, 16, 3), 'min_samples_split':range(50, 201, 25)}

    # param = {'min_samples_split':range(10, 50, 10), 'min_samples_leaf':range(10, 60, 10)}


    tStart = time.time()#計時開始
    grid_search(X, Y.T[0], model, param)
    tEnd = time.time()#計時結束
    print(time.strftime('%H:%M:%S', time.gmtime(tEnd - tStart)))