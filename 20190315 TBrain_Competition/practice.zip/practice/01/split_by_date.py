import os
import pandas as pd

def split_func(INPUT_FILE):

    df = pd.read_csv(INPUT_FILE)

    df.sort_values('TXN_DT')

    df_1 = df[df.TXN_DT < 9478]

    df_1.to_csv(os.path.join("test.csv"), sep='\t')

if __name__ == '__main__':

    INPUT_FILE = "./data/TBN_CC_APPLY.csv"

    split_func(INPUT_FILE)