import os
import time
from datetime import date

import pickle
import numpy as np

from sklearn import preprocessing
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.metrics import f1_score


def chkDir(DIR_PATH):
    if not os.path.exists(DIR_PATH):
        os.makedirs(DIR_PATH)

def get_RFC_Classifier(X, y, OUTPUT_PATH, SAVE_MODEL):
    
    forest = RandomForestClassifier(random_state=1, n_estimators=100)

    # 建構多輸出分類器
    multi_target_forest = MultiOutputClassifier(forest)
    multi_target_forest.fit(X, y)
    y_pred = multi_target_forest.predict(X)
    
    if SAVE_MODEL:
        with open(OUTPUT_PATH, 'wb') as fw:
            pickle.dump(multi_target_forest, fw)

    evaluation(y, y_pred)

def evaluation(Y_ans, Y_pred):

    # TODO
    # OUTPUT = [?, ?, ?, ?]
    # f1_score
    # https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html
    

def train_with_grid_search():
    param_test1 = {'n_estimators':range(10,71,10)}

if __name__ == "__main__":

    SAVE_MODEL = True
    OUTPUT_DIR = "./model/Classifier"
    OUTPUT_PATH_WITH_DATE = os.path.join(OUTPUT_DIR, str(date.today()))
    chkDir(OUTPUT_PATH_WITH_DATE)
    OUTPUT_FILE_NAME = "rfc.pkl"

    X_path = './data/training_data.npy'
    X = np.load(X_path)
    # TODO
    # print("Normalizing data matrix ...")
    # X = preprocessing.normalize(X, norm='l2')
    print(X.shape)

    Y_path = './data/label_data.npy'
    Y = np.load(Y_path)
    print(Y.shape)

    tStart = time.time()#計時開始
    print("Start training ...")

    # TODO
    model = get_RFC_Classifier(X, Y, os.path.join(OUTPUT_PATH_WITH_DATE, OUTPUT_FILE_NAME), SAVE_MODEL)
    
    tEnd = time.time()#計時結束
    print(time.strftime('%H:%M:%S', time.gmtime(tEnd - tStart)))
