# -*- coding: utf-8 -*-
"""EDA.ipynb
# Prepare Data
"""
# # !pip install prince
# # !pip install pandas-profiling
import pandas as pd
import numpy as np
from prince import MCA
import pandas_profiling
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.impute import SimpleImputer
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

train = pd.read_csv('train.csv', encoding = 'Big5')
# test = pd.read_csv('test.csv', encoding = 'Big5')
"""# View """
profile = train.profile_report(title='Pandas Profiling Report')
profile.to_file(output_file="train.html")




"""# Preprocess"""
X_train = train.drop(['CUS_ID', 'Y1'], 1)
y_train = train['Y1']
# X_test = test.drop('CUS_ID', 1)
# X = pd.concat([X_train, X_test])
X=X_train
X.head()

def preprocess(df):
  
  # add a new feature
  #df['AG_PERCENTAGE'] = df['AG_NOW_CNT'] / df['AG_CNT'] 
  
  # descretize L1YR_C_CNT 
  df['L1YR_C_CNT'] = pd.cut(df.L1YR_C_CNT,
							bins = [0, 5, 10, 15, 20, 25, 30, 42],
							labels = ['1', '2', '3', '4', '5', '6', '7'])
  
  # transform to categorical features
  df['EDUCATION_CD'] = pd.Categorical(df['EDUCATION_CD'])
  df['MARRIAGE_CD'] = pd.Categorical(df['MARRIAGE_CD'])
  
  # numeric features, categorical features
  num = list(set(df._get_numeric_data().columns))
  cate = list(set(df.columns) - set(num))
  complete_NY = ['LAST_A_CCONTACT_DT', 'LAST_A_ISSUE_DT', 'LAST_B_ISSUE_DT', 'IF_2ND_GEN_IND',
                 'IF_ISSUE_A_IND', 'IF_ISSUE_B_IND', 'IF_ISSUE_C_IND', 'IF_ISSUE_D_IND',
                 'IF_ISSUE_E_IND', 'IF_ISSUE_F_IND', 'IF_ISSUE_G_IND', 'IF_ISSUE_H_IND',
                 'IF_ISSUE_I_IND', 'IF_ISSUE_J_IND', 'IF_ISSUE_K_IND', 'IF_ISSUE_L_IND',
                 'IF_ISSUE_M_IND', 'IF_ISSUE_N_IND', 'IF_ISSUE_O_IND', 'IF_ISSUE_P_IND',
                 'IF_ISSUE_Q_IND', 'IF_ADD_F_IND', 'IF_ADD_L_IND', 'IF_ADD_Q_IND',
                 'IF_ADD_G_IND', 'IF_ADD_R_IND', 'IF_ADD_IND', 'L1YR_PAYMENT_REMINDER_IND',
                 'L1YR_LAPSE_IND', 'LAST_B_CONTACT_DT', 'LAST_C_DT', 'IF_S_REAL_IND', 'IF_Y_REAL_IND',
                 'IM_IS_A_IND', 'IM_IS_B_IND', 'IM_IS_C_IND', 'IM_IS_D_IND', 
                 'IF_HOUSEHOLD_CLAIM_IND']
  cate = list(set(cate) - set(complete_NY))
  
  # label
  df = df.replace(['低', '中', '中高', '高', 'Y', 'N'], ['low', 'medium', 'mediumhigh', 'high', 1, 0])
  
  # na indicator
  df['AMT_na'] = df['MONTHLY_CARE_AMT'].isnull().astype(int)
  df['TERMINATION_RATE_na'] = df['TERMINATION_RATE'].isnull().astype(int)
  df['BMI_na'] = df['BMI'].isnull().astype(int)
  df['TERMINATION_RATE_na'] = df['TERMINATION_RATE'].isnull().astype(int)
  df['ANNUAL_INCOME_AMT_na'] = df['ANNUAL_INCOME_AMT'].isnull().astype(int)
  df['ANNUAL_PREMIUM_AMT_na'] = df['ANNUAL_PREMIUM_AMT'].isnull().astype(int)
  df['APC_1ST_YEARDIF_na'] = df['APC_1ST_YEARDIF'].isnull().astype(int)
  
  # dummy
  df = pd.get_dummies(df, columns = cate, dtype = float)
  cate = list(set(df.columns) - set(num))
  return (num, cate, df)

x_num, x_cate, X = preprocess(X)
X_train = X.iloc[0:100000, :]
X_test = X.iloc[100000:250000, :]

"""# Dimension Reduction for categorical features (Multiple Correspondence Analysis)

## Tow Dimension Visualization
# """

X_cate = X[x_cate] 
mca = MCA(n_components = len(x_cate))
mca = mca.fit(X_cate)
X_cate_mca = mca.transform(X_cate)

X_train_cate_mca = X_cate_mca.iloc[0:100000, :]
X_test_cate_mca = X_cate_mca.iloc[100000:250000, :]

colors = ['r', 'b']
markers = ['s', 'x']
fig = plt.figure(figsize = (10, 10))
ax = fig.add_subplot(1, 1, 1, projection = '3d')

for l, c, m in zip(np.unique(y_train.values), colors, markers):
  ax.scatter(X_train_cate_mca.loc[y_train.values == l, 0],
             X_train_cate_mca.loc[y_train.values == l, 1],
             X_train_cate_mca.loc[y_train.values == l, 2],
             label = l, marker = m)
plt.title('MCA 3D')
ax.set_xlabel('Dim 1 ({i:.2f} %)'.format(i = mca.eigenvalues_[0]*100))
ax.set_ylabel('Dim 2 ({i:.2f} %)'.format(i = mca.eigenvalues_[1]*100))
ax.set_zlabel('Dim 3 ({i:.2f} %)'.format(i = mca.eigenvalues_[2]*100))  
plt.legend(loc = 'upper right')  
#ax.view_init(30, 80)  
ax.view_init(30, 100)
plt.show()
"""## First, Second, Third Component"""

## loadings
mca.column_coordinates(X_cate)
mca.plot_coordinates(X_cate)
plt.show()
"""## How many components do we need ?"""



plt.plot(range(1, len(x_cate)+1), np.cumsum(mca.eigenvalues_))
plt.axhline(y = 0.9, color = 'red', linestyle = 'dashed')
plt.xlabel('components')
plt.ylabel('cumulative explained variation')
plt.tight_layout()
plt.show()

#np.cumsum(mca.eigenvalues_)[np.where(np.cumsum(mca.eigenvalues_) > 0.99)]
np.where(np.cumsum(mca.eigenvalues_) > 0.9)
#123 component

"""# Dimension Reduction for numerical features (Principle Componente Analysis)

## Imputation
"""

from sklearn.impute import SimpleImputer
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# median
X_num = X[x_num]
imp = SimpleImputer(missing_values = np.nan, strategy = 'median')
X_num_median = imp.fit_transform(X_num)
pca = PCA(n_components = len(x_num))
X_num_median_std = StandardScaler().fit_transform(X_num_median)
X_num_pca = pca.fit_transform(X_num_median_std)

X_train_num_pca = X_num_pca[0:100000, :]

"""## Visualization"""

# Visualization

colors = ['r', 'b']
markers = ['s', 'x']
fig = plt.figure(figsize = (10, 10))
ax = fig.add_subplot(1, 1, 1, projection = '3d')

for l, c, m in zip(np.unique(y_train.values), colors, markers):
  ax.scatter(X_train_num_pca[y_train.values == l, 0],
             X_train_num_pca[y_train.values == l, 1],
             X_train_num_pca[y_train.values == l, 2],
             label = l, marker = m)
plt.title('PCA 3D')
ax.set_xlabel('Dim 1 ({i:.2f} %)'.format(i = pca.explained_variance_ratio_[0]*100))
ax.set_ylabel('Dim 2 ({i:.2f} %)'.format(i = pca.explained_variance_ratio_[1]*100))
ax.set_zlabel('Dim 3 ({i:.2f} %)'.format(i = pca.explained_variance_ratio_[2]*100))  
plt.legend(loc = 'upper right')  
ax.view_init(30, 100)  
#ax.view_init(30, 80)

"""## How many components do we need ?"""

plt.plot(range(1, len(x_num)+1), np.cumsum(pca.explained_variance_ratio_))
plt.axhline(y = 0.9, color = 'red', linestyle = 'dashed')
plt.xlabel('components')
plt.ylabel('cumulative explained variation')
plt.tight_layout()
plt.show()

np.where(np.cumsum(pca.explained_variance_ratio_) > 0.9)

"""# Cluster

## K-means
"""

# K-means
from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters = 2)
kmeans.fit(X_cate_mca)

# Visualization

colors = ['r', 'b']
markers = ['s', 'x']
fig = plt.figure(figsize = (10, 10))
ax = fig.add_subplot(1, 1, 1, projection = '3d')

for l, c, m in zip(np.unique(kmeans.labels_), colors, markers):
  ax.scatter(X_train_cate_mca.loc[kmeans.labels_[0:100000] == l, 0],
             X_train_cate_mca.loc[kmeans.labels_[0:100000] == l, 1],
             X_train_cate_mca.loc[kmeans.labels_[0:100000] == l, 2],
             label = l, marker = m)
  
ax.view_init(30, 80)
plt.show()
"""## Gaussian Mixture"""

#GaussianMixture
from sklearn.mixture import GaussianMixture

gaussianmixure = GaussianMixture(n_components = 2, max_iter = 300)
gaussianmixure.fit(X_cate_mca.iloc[:,0:3])
gaussianmixure_labels=gaussianmixure.predict(X_cate_mca.iloc[:,0:3])

# Visualization

colors = ['g', 'r']
markers = ['s', 'x']
labels =['Group1','Group2']
fig = plt.figure(figsize = (10, 10))
ax = fig.add_subplot(1, 1, 1, projection = '3d')

for ls,l, c, m in zip(labels,np.unique(gaussianmixure_labels), colors, markers):
  ax.scatter(X_cate_mca.loc[gaussianmixure_labels == l, 0],
             X_cate_mca.loc[gaussianmixure_labels == l, 1],
             X_cate_mca.loc[gaussianmixure_labels == l, 2],
             label = ls, marker = m,color=c)
  

plt.title('MCA 3D')

ax.set_xlabel('Dim 1 ({i:.2f} %)'.format(i = mca.eigenvalues_[0]*100))
ax.set_ylabel('Dim 2 ({i:.2f} %)'.format(i = mca.eigenvalues_[1]*100))
ax.set_zlabel('Dim 3 ({i:.2f} %)'.format(i = mca.eigenvalues_[2]*100))  
plt.legend(loc = 'upper right')  
#ax.view_init(30, 100)
ax.view_init(30, 80)
plt.show()

# """# XGBoost"""

# #train, test

# X_pca_mca = pd.DataFrame(data = np.hstack((X_num_pca[:, 0:25], X_cate_mca.iloc[:, 0:83])),
#                          columns = np.append(["pca_" + str(i) for i in range(1,26)], ["mca_" + str(i) for i in range(1,84)]))
# y = train['Y1']
# X = X_pca_mca.iloc[0:100000,:]
# X_test = X_pca_mca.iloc[100000:250000,:]

# from sklearn.model_selection import StratifiedShuffleSplit

# # validation
# #sss = StratifiedShuffleSplit(n_splits = 2, test_size = 0.2, random_state = 0)
# #train1_idx, train2_idx = sss.split(X, y)
# #X_train, X_valid = X.iloc[train1_idx[0], :], X.iloc[train1_idx[1],:]
# #y_train, y_test = y[train1_idx[0]], y[train1_idx[1]]

# # def StratifiedSplit(X, y):
# #   sss = StratifiedShuffleSplit(n_splits = 2, test_size = 0.2, random_state = 0)
# #   train1_idx, train2_idx = sss.split(X, y)
# #   X_train, X_valid = X.loc[train1_idx[0], :], X.loc[train1_idx[1],:]
# #   print(y.head())
# #   print(y[train1_idx[0]].head())
# #   print(train1_idx[0][0:5])
# #   y_train, y_test = y.loc[train1_idx[0], ], y.loc[train1_idx[1], ]
# #   return X_train, X_valid, y_train, y_test

# from random import sample 

# def train_valid(X, y, valid_ratio = 0.2):
#   y = pd.DataFrame(data = y, columns = ['Y1'])
#   df = pd.DataFrame(data = np.hstack((X, y)), columns = np.append(X_group0.columns.values, ['Y1']))
  
#   count_N, count_Y = df.Y1.value_counts()
#   df_Y = df[df.Y1 == 'Y']
#   df_N = df[df.Y1 == 'N']
  
#   df_N_valid = df_N.sample(int(count_N*valid_ratio), replace = False)
#   df_Y_valid = df_Y.sample(int(count_Y*valid_ratio), replace = False)
#   valid = pd.concat([df_N_valid, df_Y_valid], axis=0)
  
#   df_N_train = df_N.drop(df_N_valid.index.values)
#   df_Y_train = df_Y.drop(df_Y_valid.index.values)
#   train = pd.concat([df_N_train, df_Y_train], axis=0)
  
#   return train.drop('Y1', 1).astype('float'), valid.drop('Y1', 1).astype('float'), train['Y1'], valid['Y1']

# X_group0 = X.loc[gaussianmixure_labels[0:100000] == 0, :]
# X_group1 = X.loc[gaussianmixure_labels[0:100000] == 1, :]
# y_group0 = y.loc[gaussianmixure_labels[0:100000] == 0, ]
# y_group1 = y.loc[gaussianmixure_labels[0:100000] == 1, ]
# index_group0 =np.where(gaussianmixure_labels[0:100000]==0)
# index_group1 =np.where(gaussianmixure_labels[0:100000]==1)

# # group 0 xgboost
# X_train, X_valid, y_train, y_valid = train_valid(X_group0, y_group0)

# X_train.dtypes

# from xgboost import XGBClassifier
# from sklearn.model_selection import GridSearchCV
# from sklearn.model_selection import StratifiedKFold
# from sklearn.model_selection import RandomizedSearchCV

# # colsample_bytree: col的抽樣比例，越高表示每棵樹使用的col越多，會增加每棵小樹的複雜度
# # subsample: row的抽樣比例，越高表示每棵樹使用的row越多，會增加每棵小樹的複雜度
# # max_depth: 樹的最大深度，越高表示模型可以長得越深，模型複雜度越高
# # eta: boosting會增加被分錯的資料權重，而此參數是讓權重不會增加的那麼快，因此越大會讓模型愈保守
# # gamma: 越大，模型會越保守，相對的模型複雜度比較低
# param = {'objective': 'binary:logistic',
#          'eval_metric': 'auc',
#          'max_depth': 4,
#          'min_child_weight': 3,
#          'gamma': 0.04, 
#          'colsample_bytree': 0.9,
#          'subsample': 0.9,
#          'reg_alpha': 0.01
#         }
# param_grid = {'max_depth': [3, 4, 5],
#               'min_child_weight': [2, 3, 4]}

# def XGB(X_train,  y_train):
#   xgb = XGBClassifier(**param)
#   skf = StratifiedKFold(n_splits = 5, shuffle = False)
#   random_search = RandomizedSearchCV(xgb, param_distributions = param_grid, n_iter = 10,
#                                    scoring = 'roc_auc', n_jobs = 4, cv = skf, verbose = 3)
#   random_search.fit(X_train, y_train)
#   print('\n Best Scores:')
#   print(random_search.best_score_ )
#   print('\n Best estimator:')
#   print(random_search.best_estimator_)
#   print('\n Best hyperparameters:')
#   print(random_search.best_params_)

# # group 0
# XGB(X_train, y_train)

# """# RandomForest"""

# # from sklearn.ensemble import RandomForestClassifier
# # from sklearn.metrics import accuracy_score

# # rf = RandomForestClassifier(criterion = 'entropy',
# #                              n_estimators = 200,
# #                              random_state = 1,

# #                             n_jobs = 2)
# # # group 0 rf
# # X_train_g0, X_valid_g0, y_train_g0, y_valid_g0 = train_valid(X_group0, y_group0)

# # rf_g0 = rf.fit(X_train_g0, y_train_g0)
# # y_pred_g0 = rf.predict(X_valid_g0)
# # # group 1 rf
# # X_train_g1, X_valid_g1, y_train_g1, y_valid_g1 = train_valid(X_group1, y_group1)
# # rf_g1 = rf.fit(X_train_g1, y_train_g1)
# # y_pred_g1 = rf.predict(X_valid_g0)

# validation(rf_g0, rf_g1, X_valid_g0, y_valid_g0, X_valid_g1, y_valid_g1)

# from sklearn import metrics
# from sklearn.metrics import confusion_matrix
# def validation(clf1, clf2, x_valid_g0, y_valid_g0, x_valid_g1, y_valid_g1):
#     y_predict_g0 = clf1.predict_proba(X_valid_g0)[:, 1]
#     fpr, tpr, thresholds = metrics.roc_curve(y_valid_g0, y_predict_g0, pos_label='Y')
#     auc = metrics.auc(fpr, tpr)
#     print("Group 0 AUC = ", auc)
#     plt.plot(fpr, tpr, 'b', label="Group 0 AUC="+str(round(auc,3)))
#     plt.plot([0, 1],[0, 1], 'r--', label="Baseline")
#     plt.legend(loc=4)
#     plt.show()
    
#     y_predict_g1 = clf2.predict_proba(X_valid_g1)[:, 1]
#     fpr, tpr, thresholds = metrics.roc_curve(y_valid_g1, y_predict_g1, pos_label='Y')
#     auc = metrics.auc(fpr, tpr)
#     print("Group 1 AUC = ", auc)
#     plt.plot(fpr, tpr, 'b', label="Group 1 AUC="+str(round(auc,3)))
#     plt.plot([0, 1],[0, 1], 'r--', label="Baseline")
#     plt.legend(loc=4)
#     plt.show()
    
#     y_predict = np.concatenate((y_predict_g0, y_predict_g1), axis=0)
#     y_test = np.concatenate((y_valid_g0, y_valid_g1), axis=0)
    
#     fpr, tpr, thresholds = metrics.roc_curve(y_test, y_predict, pos_label='Y')
#     auc = metrics.auc(fpr, tpr)
#     print("AUC = ", auc)
#     plt.plot(fpr, tpr, 'b', label="Total AUC="+str(round(auc,3)))
#     plt.plot([0, 1],[0, 1], 'r--', label="Baseline")
#     plt.legend(loc=4)
#     plt.show()

# """# SVM"""

# from sklearn.preprocessing import StandardScaler
# from sklearn.svm import SVC

# sc = StandardScaler()
# X_train_std = sc.fit_transform(X_train)
# X_valid_std = sc.fit_transform(X_valid)

# svm_rbf = SVC(kernel = 'rbf', random_state = 0, gamma = 0.2, C = 10.0)
# svm_rbf.fit(X_train_std, y_train)
# y_pred = svm_rbf.predict(X_valid_std)

# print('[Nonlinear SVC]')
# print('Misclassified samples: %d' % (y_valid != y_pred).sum())
# print('Accuracy: %.2f' % accuracy_score(y_valid, y_pred))

# from sklearn import metrics
# from sklearn.metrics import confusion_matrix
# def validation(clf, x_test, y_test):
#     y_predict = clf.predict_proba(x_test)[:, 1]
#     print(y_predict)
#     fpr, tpr, thresholds = metrics.roc_curve(y_test, y_predict, pos_label='Y')
#     auc = metrics.auc(fpr, tpr)
#     print("AUC = ", auc)
#     plt.plot(fpr, tpr, 'b', label="AUC="+str(round(auc,3)))
#     plt.plot([0, 1],[0, 1], 'r--', label="Baseline")
#     plt.legend(loc=4)
#     plt.show()

# validation(rf. X_valid, y_valid )

# """# Logistic"""

# from sklearn.linear_model import LogisticRegression
# def logistic_regression(X_train,y_train,X_test):
#   clf = LogisticRegression(random_state=3, solver='lbfgs',
#                        multi_class='ovr').fit(X_train, y_train)
#   X_predict = clf.predict_proba(X_test) 
#   return X_predict

# # group 0 logistic
# X_train, X_valid, y_train, y_valid = train_valid(X_group0, y_group0)
# group0_log = logistic_regression(X_train, y_train,X_valid)


# # group 1 logistic
# X_train, X_valid, y_train, y_valid = train_valid(X_group1, y_group1)
# group1_log = logistic_regression(X_train, y_train,X_valid)

