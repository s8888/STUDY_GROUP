package _0_List;

import java.nio.charset.Charset;

import org.apache.zookeeper.KeeperException;

public class ListData extends ConnectionWatcher {
	private static final Charset CHARSET = Charset.forName("UTF-8");

	public void list(String zodeName) throws KeeperException, InterruptedException {
		String path = "/" + zodeName;
		try {
			byte[] data = zk.getData(path, this, null/* stat */);

			if (data == null) {
				System.out.printf("No data in node %s\n", zodeName);
				System.exit(1);
			}
			System.out.printf(new String(data, CHARSET));
		} catch (KeeperException.NoNodeException e) {
			System.out.printf("Group %s does not exist\n", zodeName);
			System.exit(1);
		}
	}

	public static void main(String[] args) throws Exception {
		ListData listData = new ListData();
		listData.connect("192.168.99.100:2181"); // TODO
		listData.list("zoo");// TODO
		listData.close();
	}
}
